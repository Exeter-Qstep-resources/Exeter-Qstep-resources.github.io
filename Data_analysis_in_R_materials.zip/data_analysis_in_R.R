# Data Analysis with R
# Exeter Q-Step Workshops
# Iulia Cioroianu and Travis Coan
# February 2016

#######################################################################
#Part 1: Methods overview
#######################################################################

################################################                    
# Importing and saving your own data
################################################

#"Import data" in the Environment window
# Make sure you give the imported data frame a short name. 
# Check 'Yes' for heading if the variable names are on the first row.

# OR: 
# Set the working directory to be the folder where you have the data:
setwd("U:/DataAnalysisR/")
# now you can read the data directly from the folder. Everything that you save will also go to that folder. 
read.csv("mydataset.csv")

# OR:
data <- read.csv(file.choose(''), header=TRUE)
# Now choose the file to open. 

# OR
# Use file location (make sure you change this to match the location where you saved the file):
data <- read.csv("U:/DataAnalysisR/mydataset.csv")

# Saving data
# Let's say you have a data frame object called 'mydata' that you want to save as a .csv file: 
write.csv(data, file="U:/DataAnalysisR/saved_data.csv")
# Or, if you've already set the working directory just give it a name and it will automatically be saved in the working directory location. 
write.csv(data, file="saved_data.csv")


#######################################################
# Descriptive statistics
#######################################################

# Mean, median, 25th and 75th quartiles, min, max, number of NA (if no NA given then no NAs exist for that variable)
summary(data) # for ALL the variables in the dataset:
summary(data$spent) # for a single variable 

# One measure at a time
length(na.omit(data$reelected)) # The number of non-missing observations
mean(data$reelected, na.rm=T)            # The mean
sd(data$reelected, na.rm=T)              # The standard deviation
min(data$reelected, na.rm=T)             # The minimum value
max(data$reelected, na.rm=T)             # The maximum value

# Using the "psych" package:
install.packages('psych') # install psych if it is not already installed. You only do this once.
library(psych)            # load the package into your R session
describe(data)            # Get descriptive statistics

#######################################################
# Frequency and proportions tables: 
#######################################################

# Frequency table:
mytable <- table(data$party,data$reelected) # var1 will be on the rows, var2 will be on the columns
mytable # print table
# Relative frequency (or proportions) table. Note that this is a table of the frequency table defined above. 
prop.table(mytable) # cell percentages
prop.table(mytable, 1) # row percentages
prop.table(mytable, 2) # column percentages 


#######################################################
# Simple plots
#######################################################

# General syntax:
# PlotType(data_to_plot, option1, option2, option3, etc)
# where:
# PlotType can be: plot(does a scatterplot), barplot, pie (for piechart), hist(for histogram), boxplot, etc. 
# data_to_plot can be a variable, a table, data coming from some model, etc. 
# options can be: 'main' and 'sub' for main title and sub-title; 'col' for changing colors; 'ylab' and 'xlab' for labeling the axes; legend; names.arg for labeling plot elements etc. 

#Let's first attach the dataset so we can refer to variable names directly
attach(data)

# Examples:

# Histogram: 
hist(spent) # simple histogram
hist(spent, breaks=12, col="red") # red histogram with different number of bins  

# Barplots:
barplot(table(reelected)) # Simple bar plot of a a frequency table for a variable (an ordinal or binary variable)
barplot(table(reelected), main="Number of observation per category of var2", xlab="Category of var2") # Same plot with title and labeled x axis
barplot(table(reelected,party)) # stacked bar plot of the number of observations by group of var1 and var2
barplot(prop.table(table(reelected,party)), col=c("red", "blue", "green", "yellow", "black", "purple")) # stacked bar plot of the proportion of observations per group of var1 and var2, also with different colors for the categories of var1
barplot(prop.table(table(reelected,party)), col=rainbow(6), beside=TRUE) # same as above, but grouped bar plot (not stacked but aside) and letting R choose the colors

# Piecharts
pie(table(party)) # Simple pie chart of var1
#Put two graphs in the same plot, one next to the other:
par(mfrow=c(1,2)) # This divides the plotting space into two vertical cells
pie(table(party))
pie(table(chamber))
par(mfrow=c(1,1)) # This turns it back to a single cell

# Dotcharts
dotchart(table(data$party, data$chamber)) # number of legislators by party and chamber
# Now make it pretty: 
dotchart(table(data$party, data$chamber), cex=1.2, color=c("orange", "red", "blue"), 
         main="Legislators by house and party",
         xlab="Number of legislators")

# Scatterplots
plot(spent, raised) # Simple scatterplot of variables x and y. 
#This order puts x on the horizontal axis and y on the vertical one. 
#Note that the order is particularly important if you want to add a linear fit line:  
abline(lm(spent~raised), col="red") # add a regression line (y~x)
lines(lowess(spent, raised), col="blue")
# Matrices of scatterplots, for multiple variables (two by two)
pairs(~spent+raised+reelected, data=data, main="Simple Scatterplot Matrix")

##############################################
# Correlations
##############################################

cor(data$spent, data$raised) # correlation between var1 and var2. var1 and var2 need to be numeric. 
cor(data$spent, data$raised, use="complete.obs") # only use complete cases if there is any missing data in var1 and var2. 
cor.test(data$spent, data$raised, use="complete.obs") # test significance

#######################################################
# Hypothesis testing
#######################################################

### Independent 2-group t-test.
### Test if the means for two groups are equal. 

# Is the average money raised the same for House and Senate?  
# The t-test tests if the difference between the two groups' averages is unlikely to have occurred because of random chance in sample selection.
#H0: There is no difference in means between the two groups. The difference is 0. 
#HA: The difference in means is not equal to 0. 

t.test(data$spent~data$chamber)

# The p-value is the probability of observing a greater absolute value of the t-statistic under the null hypothesis.
# If the p-value associated with the test-statistic is smaller than 0.05, then there is evidence that the mean is different from the reference value. 
# If the p-value associated with the t-test is not small (p > 0.05), then the null hypothesis cannot be rejected.  

# To change the required confidence level: 
t.test(data$spent~data$chamber, conf.level=0.99)
# By default, R assumes unequal variances, so it applies a df correction. To get the t-test without the correction: 
t.test(data$spent~data$chamber, var.equal = TRUE)
# Also by default, a two-tailed test is done. To do a one-tailed test use options "less" or "greater":
t.test(data$spent~data$chamber, alternative="less", var.equal = TRUE)
# What is the alternative hypothesis in this case? 
# Note that tested difference is first group (H) minus second group (S). 

#######################################################
# Regression analysis
#######################################################

# Simple Linear Regression Example
model1 <- lm(data$spent~data$raised)
summary(model1)
#OR: 
model2 <- lm(spent~raised, data=data)
summary(model1) # show results

# Multiple Linear Regression Example
# Generate a new variable, 'house' which is 1 of chamber==house and 0 if not. 
data$house <- ifelse(data$chamber=="H", 1, 0)
# Although R understands that chamber is a binary variable and you can introduce it in the model just as it is. 
model3 <- lm(spent~raised+house+reelected, data=data)
summary(model3) # show results

# Useful functions for getting info from the model
coefficients(model3) # model coefficients
confint(model3, level=0.95) # CIs for model parameters
fitted_values <- fitted(model3) # predicted values
model_residual <- residuals(model3) # residuals

######################################################
# Regression diagnostics
#####################################################

# Great package for regression analysis: 
install.packages("car")
library("car")

# Most commonly used: plot residuals vs fitted values. 
# Linearity. The residuals "bounce randomly" around the 0 line. This suggests that the assumption that the relationship is linear is reasonable.
# Homoskedasticity (equal variances of the error terms).The residuals roughly form a "horizontal band" around the 0 line. 
# No outliers. No residual "stands out" from the basic random pattern of residuals. 
# Remember we saved the fitted values and residuals from model 3. 
plot(fitted_values, model_residual)# a fitted values vs. residuals plot  
# What problems do you see? 
# Another useful plot for assessing outliers and normality of residuals: 
qqPlot(model3, main= "QQ Plot")

# What are the outliers?
outlierTest(model3) # Bonferonni p-value for most extreme obs

# Test for Autocorrelated Errors
durbinWatsonTest(model3)
# The null hypothesis is that there is no correlation among residuals, i.e., they are independent.
# Can we reject the null? 

# Combined diagnostic plots
layout(matrix(c(1,2,3,4),2,2)) # optional 4 graphs/page
plot(model3)
# The Scale-Location plot should look random, with no patterns.
# Cook's distance lot tells us which points have the greatest influence on the regression (leverage points). 
par(mfrow=c(1,1)) # This plot area back to a single cell


####################
#Logistic regression
####################

# Logistic Regression
# The dependent variable is a binary factor. 
model4 <- glm(house~raised,data=data,family=binomial)
summary(model4) # display results
# For every one unit increase in raised, the log odds of house (versus senate) decrease by 0.00000049. 
confint(model4) # 95% CI for the coefficients
exp(coef(model4)) # exponentiated coefficients
# Coefficients as odds ratios. 
# For a one unit increase in raised, the odds of house (versus senate) decreae by a factor of 0.999. 
exp(confint(model4)) # 95% CI for exponentiated coefficients
predicted_logit <- predict(model4, type="response") # predicted values
residuals_logi <- residuals(model4, type="deviance") # residuals 
# Plotting predicted probabilities
plot(data$raised, data$house)
curve(predict(model4,data.frame(raised=x),type="response"),add=TRUE)

###################
# Models for counts: Poisson regression
###################

# Poisson Regression
# The dependent variable is a count. 
fit <- glm(reelected ~ raised, data=data, family=poisson())
summary(fit) # display results
# Poisson regression models the log of the expected count as a function of the predictor variables. 
# For a one unit change in the independent variable, 
# the difference in the logs of expected counts is expected to change by Beta. 




#######################################################################
# Part B
# Note that this examples and data come from Kosuke Imai's soon to be #
# released "A First Course in Data Analysis". This is a must read!    #
#######################################################################

###############################################################################
# QUANTITATIVE DEPENDENT VARIABLE: Tordorov, Mandisodza, Goren, and Hall (2005)
###############################################################################

# We will start by looking at analysis in the context of a quantitative dependent
# variable, using a really cool study on facial appearance and election outcomes:

# Alexander Todorov, Anesu N. Mandisodza, Amir Goren, and Crystal C. Hall.
#   (2005). “Inferences of Competence from Faces Predict Election Outcomes.” Science, 
#   Vol. 308, No. 10 (June), pp. 1623–1626.

# Todorov et al. report the results from a series of experments that suggest facial
# appearance predicts election outcomes better than chance.

# Load the data
face <- read.csv("face.csv")
str(face)

# The data set has the following variables:
# congress -- session of congress
# year     -- year of election
# state	   -- state of election
# winner   -- name of winner
# loser	   -- name of runner-up
# w.party	 -- party of winner
# l.party	 -- party of loser
# d.votes	 -- number of votes for Democratic candidate
# r.votes	 -- number of votes for Republican candidate
# d.comp	 -- competence measure for Democratic candidate
# r.comp	 -- competence measure for Republican candidate

#-------------------------------------------------------------
# STEP 1: Cleaning

# These data are pretty much ready to go. We will, however, create two
# additional measures. The first will act as our primary dependent variable
# and is equal to the difference in vote share across Democrats and Republicans:
face$d.share <- face$d.votes / (face$d.votes + face$r.votes)
face$r.share <- face$r.votes / (face$d.votes + face$r.votes)
face$diff.share <- face$d.share - face$r.share

# Let's also create a 'high vs. low' competency indicator varible. This variable
# is not totally necessary, but we will use it to illustrate a difference in
# means test in R (aka the 't-test'). Here we will assume that anything less than
# .5 = incompetent, while anything .5 or greater equals competent:
face$d.comp.binary <- ifelse(face$d.comp >= .5, 1, 0)

#-------------------------------------------------------------
# STEP 2: Getting to know your data

# We should always start with basic descriptives, histograms, etc., to
# really get to know our data. To get relevant descriptive statistics for
# all of the variables that we are interested in, it is useful to use
# the -psych- package's describe() function:

describe(subset(face, select = w.party:d.comp.binary))

# We can also look at relevant historgrams:
hist(face$d.comp)
hist(face$r.comp)
hist(face$diff.share)

# There are many, many other things you can look at. However, these
# basic steps are sufficient in this case to 'get to know our data.'

#-------------------------------------------------------------
# STEP 3: Analysis

# A. Difference in means

# Let's start with a simplified version of the analysis to illustrate
# conducting a t-test in R. Here, we want to examine our mean differences
# in our 'diff.share' variable across the different levels of compentency 
# given by the 'd.comp.binary' variable. Combining R's tapply() and mean()
# mean function work well for this:

x_bar <- tapply(face$diff.share, face$d.comp.binary, mean)
x_bar # print the means

# Which implies the following difference in means:
x_bar_1 <- mean(face$diff.share[face$d.comp.binary == 1])
x_bar_0 <- mean(face$diff.share[face$d.comp.binary == 0])
x_bar_1 - x_bar_0

# We can also look at this graphically if you prefer:
bp <- barplot(x_bar, 
              ylab = "Democratic margin in vote share",
              ylim = c(-.2,.2),
              cex.axis = .8,
              cex.names = .8)
# The 'cex' bit just changes the size of the default labels in the plot.
abline(h=0) # add a line for horizontal axis

# You can find out all the ways to customize this barplot, by typing
# ?barplot in the R console. However, the he outstanding question remains:
# is whether this difference is due to sampling error. To examine this
# question, we can conduct a simple difference in means test using R's
# t.test() function:

t.test(face$diff.share[face$d.comp.binary == 1], 
       face$diff.share[face$d.comp.binary == 0])

# This gives all the typical information: confidence interval around the 
# difference, p-value, etc. That's it! Pretty easy, right?

# B. Regression

# The t-test above is useful for illustration purposes, but it is a silly
# analysis in this context. As Tordov et al. (2005) used in the paper,
# a regression analysis is a good approach here. Before jumping into the
# analysis, it is useful to get some descriptives on the relationship
# between diff.share and d.comp. With two quantitative variables, a scatter
# plot is a good way to go:

face$w.party <- as.character(face$w.party) # coerce to character for plot
plot(face$d.comp, face$diff.share, pch = face$w.party,
     col = ifelse(face$w.party == "R", "red", "blue"),
     xlim = c(0, 1), ylim = c(-1, 1),
     xlab = "Competence scores for Democrats",
     ylab = "Democratic margin in vote share",
     main = "Facial Competence and Vote Share")

# Here we did a little modification to improve the look of the plot, but this
# isn't totally necessary (again, type ?plot for more). The relationship looks
# positive and we can confirm this by looking at the correlation:

cor(face$d.comp, face$diff.share)

# A bivariate correlation of .43 is pretty high, so there is some preliminary evidence
# of a positive relationship. We can now move to a bivariate regression analysis, which
# fits a line to this scatter plot

reg <- lm(diff.share ~ d.comp, data = face)
summary(reg)

# which we can also display visually using:

plot(face$d.comp, face$diff.share, xlim = c(0, 1.05), ylim = c(-1, 1),
     xlab = "Competence scores for Democrats",
     ylab = "Democratic margin in vote share",
     main = "Facial Competence and Vote Share")
abline(reg) # add regression line
abline(v = 0, lty = "dashed")

# Note that multiple regressin works the same way. You just add additional variables to
# the right-hand side of the lm() function is a 'plus' (+) sign:

reg_mult <- lm(diff.share ~ d.comp + d.comp.binary, data = face)
summary(reg_mult)

# Note that this model doesn't really make sense! However, it does illustrate how easy
# it is to estimate a multiple regression.

# Try at hime: test the regression assumptions!  


#######################################################################
# BINARY DEPENDENT VARIABLE: Gerber, Green, and Larimer (2008)
#######################################################################

# We will analyze data from Gerber et al.'s famous field experiment:
#   
# Alan S. Gerber, Donald P. Green, and Christopher W. Larimer. (2008). “Social
#   Pressure and Voter Turnout: Evidence from a Large-Scale Field Experiment.” 
#   American Political Science Review, Vol. 102, No. 1, pp. 33–48.
# 
# The study seeks to examine the relationship between social pressure and turnout. 
# The authors induce social pressure by telling voters that after the election their 
# neighbors will be informed about whether they voted in the election or not. The
# hypothesis is that 'naming and shaming' non-voters would increase turnout.

# Load the Gerber et al (2008) data
dat <- read.csv('social.csv')

# You can first see what we actually loded in using the str() function in R,
str(dat)

# or by clicking through the RStudio user interface. These variables have the 
# following meaning:

# hhsize      -- household size of voter
# messages    -- GOTV messages voter received (Civic, Control,
#                Neighbors, Hawthorne)
# sex         -- sex of voter (female or male)
# yearofbirth -- year of birth of voter
# primary2004 -- whether a voter turned out in the 2004 Primary 
#                election (1=voted, 0=abstained)
# primary2008 -- whether a voter turned out in the 2008 Primary 
#                election (1=voted, 0=abstained)

#-------------------------------------------------------------
# STEP 1: Cleaning

# It is useful to create a couple of variables before we get going:

dat$female <- ifelse(dat$sex == "female", 1, 0) # dummy variable for gender
# Generate dummies for treatments:
dat$neighbors <- ifelse(dat$messages == "Neighbors", 1, 0)
dat$control <- ifelse(dat$messages == "Control", 1, 0)
dat$civic <- ifelse(dat$messages == "Civic Duty", 1, 0)
dat$hawthorne <- ifelse(dat$messages == "Control", 1, 0)
# And age in years
dat$age <- 2008 - dat$yearofbirth

#-------------------------------------------------------------
# STEP 2: Descriptives

# Before moving to examining the effect os social pressure on turnout
# it is useful to examine some basic descriptives. Using the -pysch-
# package:
describe(subset(dat, select = c(primary2004, primary2008, hhsize, female, neighbors,
                                control, civic, hawthorne, age)))

# Here we use the subset function to only get the variables that we want to look at.
# Oherwise, you can pass the whole dataframe. So the sample is evenly split among
# males and females, is roughly 52 years old, and turnout had descreased since 2004.

# We might also want to check whether treatment assignment appears to have
# worked effectively by examining balance across pre-treatment measures:

tapply(dat$primary2004, dat$messages, mean) # pre-treatment turnout
tapply(dat$female, dat$messages, mean)      # gender
tapply(dat$age, dat$messages, mean)         # age
tapply(dat$hhsize, dat$messages, mean)      # household size

# These data are extremely balanced. Do there appear to differences across the various
# treatment conditions? Let's look at the means:

x_bar <- tapply(dat$primary2008, dat$messages, mean)
x_bar # print the means

# We can also look at this graphically:
bp <- barplot(x_bar, 
              ylab = "Turnout (proporition)",
              ylim = c(0,.45),
              cex.axis = .8,
              cex.names = .8)
# The 'cex' bit just changes the size of the default labels in the plot.
text(x = bp, y = x_bar, labels = round(x_bar, digits = 2), cex = .8, pos = 3)

#-------------------------------------------------------------
# STEP 3: Analysis

# A. Difference in proportions test

# So the 'neighbors' (i.e. social pressure) treatment is higher than all of the
# other conditions. However, could this difference just be due to sampling variation?
# Given that the dependent variable in this case (i.e., turnout) is a dummy variable,
# proportions. First, we can start by looking at the confidence interval for the
# proportion that 'turned out' in the 'neighbors' treatment:

N <- nrow(dat[dat$neighbors == 1,])               # get the number of cases, N
voted <- sum(dat$primary2008[dat$neighbors == 1]) # get the number that voted
prop.test(voted, N)                               # calculate the 95% CI
prop.test(voted, N, conf.level = 0.90)            # or the 90% CI

# The confidence interval is extremely tight, which is to be expected given the 
# sample sizes. We can also look at the 'average treatment effect' (ATE) for the
# neighbors treatment and test this effect using prop.test:

ate <- mean(dat$primary2008[dat$neighbors == 1]) - mean(dat$primary2008[dat$control == 1])
ate # print the ATE
N_control <- nrow(dat[dat$control == 1,])               # get number of cases for control group
voted_control <- sum(dat$primary2008[dat$control == 1]) # get voted for control
# test the difference in proportions
prop.test(c(voted, voted_control), n = c(N, N_control))

# Note surprising, the effect is SUPER signficant: the p-value is virtually zero and the
# confidence interval around ATE is tight. 

#*****************************************************************************************
# YOU TRY: The standard account of voting holds that a sense of 'civic duty' is critical *
# for participation. Does the civic duty treatment have an effect on turnout?            *
#*****************************************************************************************

# B. Logistic regression

# What if we though that it was necessary to control for age when doing this analysis?
# One possiblity is using a regression analysis that is suitable to a binary DV: i.e.,
# 'logit' or 'probit' analysis. We will take a look at logistic regression here. It
# turns out that this is also super easy in R -- you just switch from the lm() function
# to the glm() [i.e. generalized linear model] function:

mylogit <- glm(primary2008 ~ neighbors + civic + hawthorne + age, data = dat, 
               family = 'binomial')
summary(mylogit)

# The coefficients are logged odds ratios and these are difficult to interpret for
# most human beings. As such, it is useful to look at the predicted probabilities. Here
# is how we can do this in R:

ppdat <- with(dat, data.frame(neighbors = 0:1,
                              civic = 0, 
                              hawthorne = 0, 
                              age = mean(age)))

ppdat$predprob <- predict(mylogit, newdata = ppdat, type = "response")
ppdat$predprob

# Similarly, for civic:
ppdat <- with(dat, data.frame(neighbors = 0,
                              civic = 0:1, 
                              hawthorne = 0, 
                              age = mean(age)))

ppdat$predprob <- predict(mylogit, newdata = ppdat, type = "response")
ppdat$predprob

# C. For more information on logistic regression in R, see:
# www.ats..ucla.edu/stat/r/dae/logit.htm