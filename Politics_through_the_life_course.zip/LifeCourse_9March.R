# Data Analysis for Politics throught the Life Course
# POL3204 Politics through the Life Course
# Iulia Cioroianu & [Susan Banducci]
# 9 March, 2018 

# Skills - work with 22 wave BHPS + Understanding society, describe data and visualise individual change
# Look at change across waves

# ######################################################################
## PART 1: Types of Data 
# 1. Longitudinal a.Long and b.Wide
# 2. Cross-sectional a.single cross-section b. repeated cross-section c.comparative/crossnational
# 3. Parent-Child Dyads
# ######################################################################

# You should be able to download the data sets from the ELE page and put them into a directory 
# and point to that directory.
setwd("U:/teaching/Politics_life_course/March_9/")

# Install required packages
install.packages('lattice') 
install.packages('plyr')
install.packages('ggplot2')


## #####################################################################
## Data Set 1: Youth - Parent Socialization : 
# The Youth-Parent Socialization Panel Study is a series of surveys designed 
# to assess political continuity and change across time for biologically-related 
## generations and to gauge the impact of life-stage events and historical trends 
## on the behaviors and attitudes of respondents. A national sample of high 
## school seniors and their parents was first surveyed in 1965. Subsequent
## surveys of the same individuals were conducted in 1973, 1982, and 1997.
## In 1997 the offspring of the cohort were interviewed creating a 3rd generation 
## of respondents.This is the data we will be looking at -- members of the 1965 cohort
## and their offspring all interviewed in 1997. More details are here -
##  NAME of Data set -- parent_youth_97.RData
## The codebook will have details on questions
## For this short exercise examine the correlation between rating of Hilary Clinton
## between parent and offspring and does this differ by gender of parent?
## #####################################################################
## R Script section 1
## We will examine correlation between parent and offspring rating of Hilary Clinton
## Will see if correlation stronger for mothers or fathers
## variables used ub V7665 Hilary rating for offspring (3rd gen), V5623 hilary rating for 1968 student
## need to remove values 998 and 999 which are missing data - DK and NA
##  also need gender of student V6600

#Load the data
load("parent_youth_97.RData")
py97<-parent_youth_97

# Hillary rating for offspring:
table(py97$V7665)
mean(py97$V7665)

##remove missing values 998, 999##
py97$V7665[py97$V7665 > 990] <- NA 
py97$V5623[py97$V5623 > 990] <- NA

# Offspring evaluations of Clinton
table(py97$V7665) 
mean(py97$V7665, na.rm=TRUE)
# Parent evaluations of Clinton
table(py97$V5623)
mean(py97$V5623, na.rm=TRUE)

# Gender in the dataset:
table(py97$V6600)

# Parent evaluations by gender:
boxplot(py97$V5623~py97$V6600, id.method="y")

# Children evaluations by gender:
boxplot(py97$V7665~py97$V6600, id.method="y")


### Run a correlation (V7665 by V5623) on entire sample and then subset by parents gender

# Entire sample
cor.test(py97$V7665,py97$V5623)

# Subset
library(plyr)
ddply(py97, .(V6600), summarise, "corr" = cor(V7665, V5623, use="pairwise.complete", method = "pearson"))

##Scatterplots

# 1. Using base R
# Simple scatterplot:
plot(py97$V5623, py97$V7665, pch=21)
# Scatterplot by group: 
plot(py97$V5623, py97$V7665, pch=21, 
     bg=c("red","blue")[unclass(py97$V6600)], 
     main="Scatterplot by gender", 
     xlab="Parent", ylab="Offspring", cex.lab=1.2)
legend(x="bottomright", legend = levels(py97$V6600), col=c("red","blue"), pch=21)


#2. Using ggplot2 
library(ggplot2)
# Simple scatterplot:
ggplot(py97, aes(V5623, V7665))+geom_point()

# Scatterplot by group: 
scatter_plot <- ggplot(py97, aes(V5623, V7665, colour = factor(V6600)))
scatter_plot + geom_point() + geom_smooth(method="lm", se=FALSE)+ labs(title = "Parent - offspring relation in evaluation of Clinton, by gender", x = "Parent", y="Offspring", colour="Gender")


####################################################################
# Data Set 2 - British Household Panel Data and Understanding Society
# There are two longitudinal data files bhps_wide.Rdata & bhps_long.Rdata
#  a third longitudinal file called all_waves.Rdata (wide format) has more waves in it
# Remember that there are two types of data formats for longitudinal data - wide and long
# we will be working with the wide format of the bhps in this example

# British Household Panel Survey (BHPS) ran annually from 1991-2008, 
# replaced by Understanding Society 2009
# For all_waves.Rdata Wave 1 = 1991 (ba_varname) thru to Wave 18 = 2008 (br_varname), 
# For all_waves.Rdata Understanding Society Wave 19 (a_) = 2009  - Wave 25 (g_varname)


#####################################################################
### R Script Section 2
##Let's say we want to know who became a parent between waves 1 and 10 

load("bhps_wide.Rdata")
  
#Create a new variable which determines who became parents 
#between the years 1991 and 2006 
#(these therefore include Major's win in 1992, 
#Blairs landslide and Blairs reelection in 2001)
#Create new variable called became_parent, with value of 0 which means they did not become parents 
bhps_wide$became_parent1[bhps_wide$parent_2==0 & bhps_wide$parent_10==0] <- 0 
#Value of 1 within became_parent, means that they did become a parent within this period 
bhps_wide$became_parent1[bhps_wide$parent_2==0 & bhps_wide$parent_10==1] <- 1
#Value of 2 within became_parent, means that they remained a parent within this period 
bhps_wide$became_parent1[bhps_wide$parent_2==1 & bhps_wide$parent_10==1] <- 2 
View(bhps_wide$became_parent)

###we can then see if voting labour (lab_2 (wave 2) varies by becoming a parent)###
###you can also use similar code as above to identify those who change vote for labour between waves####

proptablab2 <-table(bhps_wide$lab_2, bhps_wide$became_parent1)
prop.table(proptablab2, 2)

proptablab7 <-table(bhps_wide$lab_7, bhps_wide$became_parent1)
prop.table(proptablab7, 2)

proptablab11 <-table(bhps_wide$lab_11, bhps_wide$became_parent1)
prop.table(proptablab11, 2)	

prop.table(lab2_7_table <- table(bhps_wide$lab_2,bhps_wide$lab_7), 1) 


###################Long data set############################
# This next series of commands works with the long data set#
# On the slides is explained the measure of parenting attitudes
## R Script Section 3 
###############################################################

load("bhps_long.Rdata")

##what are the sequences of changes in labour vote over the waves for individuals###

library(lattice) # load lattice library for xyplot function
xyplot(lab_ ~ wave | pid, data=bhps_long[700:820,], as.table=T)  #plots individual trajectories for vote intention for first 120 lines of data
xyplot(married_ ~ wave | pid, data=bhps_long[600:720,], as.table=T)  #plots individual trajectories for vote intention for first 120 lines of data
xyplot(numorgs_ ~ wave | pid, data=bhps_long[600:720,], as.table=T)  #plots individual trajectories for vote intention for first 120 lines of data



# Collapse and plot -- R Script Section 4 ###
### comparing subgroups over time in a plot###
##############################################

library(plyr)
library(ggplot2)
# Subset to split over demos
male = subset(bhps_long, sex_ == 0)
female = subset(bhps_long, sex_ == 1)

# Collapse series
df_overall <- ddply(bhps_long, .(wave), summarise,
                    overall = mean(parentatts_, na.rm = T))
df_male <- ddply(male, .(wave), summarise,
                 male = mean(parentatts_, na.rm = T))
df_female <- ddply(female, .(wave), summarise,
                   female = mean(parentatts_, na.rm = T))

# Merge series
df <- na.omit(as.data.frame(cbind(df_overall, df_male$male, df_female$female)))
names(df) <- c("wave", "overall", "male", "female")

# Plot
plt <- ggplot(df, aes(x = wave, y = overall)) +
  # Plot lines
  geom_line(aes(y = overall), colour = "black") +
  geom_line(aes(y = male), colour = "blue") +
  geom_line(aes(y = female), colour = "red") +
  # Plot points to illustrate missingness
  geom_point(aes(y = overall, x=wave), colour = "black") +
  geom_point(aes(y = male, x=wave), colour = "blue") + 
  geom_point(aes(y = female, x=wave), colour = "red") +
  labs(x = "Waves", y = "Mean of parentatts_") +
  scale_x_continuous(breaks = 1:22) +
  scale_y_continuous(limits = c(0, .5))
plt

