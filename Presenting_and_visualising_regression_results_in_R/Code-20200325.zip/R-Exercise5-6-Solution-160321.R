###############################################################################################################################
#### Project: Exeter Q-Step Workshop: Presenting regression results
#### Author: Nils-Christian Bormann
#### Task: Solution for Exercises 5&6
#### Version:
  #1# 21 Mar 2016



###############################################################################################################################
#### Header
rm(list=ls()) # remove objects from R's memory
setwd("")

liberary(read.dta13)

###############################################################################################################################
#### Data
fldat <- read.dta13("data/FL03.dta")

###############################################################################################################################
#### Analysis
## Regress gdp, population, ethnic fractionalization, and oil on democracy (ordinary least squares)
m4 <- lm(polity2l ~ lgdpenl1*Oil + lpopl1 + ethfrac, data=fldat, na.action=na.omit)
summary(m4)

###############################################################################################################################
#### Substantive Effects
############
#EXERCISE 5#
############
## create a model matrix for Model 4 that shows the difference between Oil exporters and non-exporters along different values of GDP
  # hint: check out the sequence command that creates an evenly-spaced series of values between two end points (e.g., min and max fo GDP variable)
  # hint 2: think how many predicted Polity values yuo need given the number of different GDP values and the interaction with oil

gdpoilvals <- rep(seq(min(m4$model[,"lgdpenl1"]), max(m4$model[,"lgdpenl1"]), length=70),2)
# I chose 70 values from the minimum to the maximum of GDP which corresponds appromodelimately to a step size of .1
n_gdpoil <- length(gdpoilvals)

pmat4 <- matrix(c(rep(1,n_gdpoil), # intercept
                  gdpoilvals, # GDP per capita for oil exporters and non exporters
                  c(rep(1,n_gdpoil/2), rep(0,n_gdpoil/2)),  # Oil and Non-Oil
                  rep(mean(m4$model[,"lpopl1"]), n_gdpoil),  # population
                  rep(mean(m4$model[,"ethfrac"]), n_gdpoil), # ethnic fractionalization
                  c(gdpoilvals[1:70], rep(0, n_gdpoil/2))), # GDP X Oil==1 and GDP X Oil==0
                nrow=n_gdpoil) # prediction matrix for model 4  (pmat4) 
pmat4 <- as.data.frame(pmat4) # change data type to data.frame
names(pmat4) <- c("Intercept", names(m4$model)[2:5], "gdpXoil") # label variables

pp4 <- predict(m4, pmat4, se.fit=TRUE, interval="confidence") # predict
head(pp4$fit) # check predictions


###############################################################################################################################
#### Plots

############
#EXERCISE 6#
############
## rather than only plotting the GDP effect, plot the interaction effect from GDP and oil from Model 4

## Plot GDP * oil effect
# Prepare plot data by adding x-axis values and labels
pp4plot <- data.frame(Oil=c(rep("Yes", 70), rep("No", 70)),
                      xposition = pmat4$lgdpenl1,
                      polpredict=pp4$fit[,1], 
                      lci=pp4$fit[,2], 
                      uci=pp4$fit[,3])
head(pp4plot)

ggplot(data=pp4plot) + 
  theme_bw() + # black-white theme
  xlab("GDP per capita (log)") + ylab("Predicted Polity Score") + # axis labels
  geom_line(aes(y=polpredict, x=xposition, group=Oil, linetype=Oil), size=1)  + # line of predicted values
  geom_ribbon(aes(ymin=lci, ymax=uci, x=xposition, group=Oil), size=1, alpha=0.3) + # confidence intervals
  geom_hline(yintercept=0, linetype=3) # draw a horizontal line at zero

ggsave("figures/oilXgdp_effect-ggplot-160321.pdf", width=6, height=6) # ggplot export (always saves last plot)
