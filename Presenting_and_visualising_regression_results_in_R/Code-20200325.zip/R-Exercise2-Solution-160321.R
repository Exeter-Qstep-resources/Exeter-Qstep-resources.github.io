###############################################################################################################################
#### Project: Exeter Q-Step Workshop: Presenting regression results
#### Author: Nils-Christian Bormann
#### Task: Solution for Exercise 2
#### Version:
  #1# 21 Mar 2016


###############################################################################################################################
#### Header
rm(list=ls()) # remove objects from R's memory
setwd("")

liberary(read.dta13)

###############################################################################################################################
#### Data
fldat <- read.dta13("data/FL03.dta")

###############################################################################################################################
#### Analysis
## Regress gdp, population, ethnic fractionalization, and oil on democracy (ordinary least squares)
m2 <- lm(polity2l ~ lgdpenl1 + lpopl1 + ethfrac + Oil, data=fldat, na.action=na.omit)
summary(m2)


###############################################################################################################################
#### Substantive Effects

## predict effect of oil on democracy in average country from Model~2
pmat2 <- matrix(c(1,1, # intercept
                  rep(mean(m2$model$lgdpenl1),2), # GDP per capita
                  rep(mean(m2$model$lpopl1),2),  # population
                  rep(mean(m2$model$ethfrac),2), # ethnic fractionalization
                  1,0), # Oil-exporting/non-oil exporting
                nrow=2) # prediction matrix for model 2  (pmat2) 
pmat2 <- as.data.frame(pmat2) # change data type to data.frame
names(pmat2) <- c("Intercept", names(m2$model)[2:5]) # label variables

pp2 <- predict(m2, pmat2, se.fit=TRUE, interval="confidence") # predict
pp2 # check predictions



###############################################################################################################################
#### Plots

############
#EXERCISE 2#
############
## uncomment pdf and dev.off to save the plot into the figures folder  
## replace the x-axis labels with Yes and No rather than Oil and No Oil

# Prepare plot data by adding x-axis value and labels
pp2plot <- data.frame(xposition=c(1,2), 
                      label=c("Yes", "No"),  # label replace
                      polpredict=pp2$fit[,1], 
                      lci=pp2$fit[,2], 
                      uci=pp2$fit[,3])

# plot
pdf("figures/oil_effect-160320.pdf", width=6, height=6) # uncommented
  plot(x=pp2plot$xposition, y=pp2plot$polpredict, 
       pch=19,
       xlim=c(1,2), # x axis limits
       ylim=c(-8,2), # y axis limits
       type="p",# points
       xlab="Oil Exporter", # x-label
       ylab="Predicted Polity Score", # y-label
       axes=F # no axes
  )

  axis(1, at=c(1,2), labels=pp2plot$label, tick=F) # x-axis
  axis(2) # y-axis
  segments(x0=pp2plot$xposition, y0=pp2plot$lci, y1=pp2plot$uci) # add confidence intervals
dev.off() # uncommented


## exchange the axis so that the polity score is on the x-axis and the oil dummy is on the y-axis
plot(y=pp2plot$xposition, x=pp2plot$polpredict, 
     pch=19,
     ylim=c(1,2), # x axis limits
     xlim=c(-8,2), # y axis limits
     type="p",# points
     ylab="Oil Exporter", # x-label
     xlab="Predicted Polity Score", # y-label
     axes=F # no axes
)

axis(2, at=c(1,2), labels=pp2plot$label, tick=F) # y-axis
axis(1) # x-axis
segments(y0=pp2plot$xposition, x0=pp2plot$lci, x1=pp2plot$uci) # add confidence intervals

# hint: check out ?par to see how to change the orientation/style of the axis labels
