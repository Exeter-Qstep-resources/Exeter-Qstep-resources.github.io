###############################################################################################################################
#### Project: Exeter Q-Step Workshop: Presenting regression results
#### Author: Nils-Christian Bormann
#### Task: Solution for Exercises 3&4
#### Version:
  #1# 21 Mar 2016



###############################################################################################################################
#### Header
rm(list=ls()) # remove objects from R's memory
setwd("")

liberary(read.dta13)

###############################################################################################################################
#### Data
fldat <- read.dta13("data/FL03.dta")

###############################################################################################################################
#### Analysis
## Regress gdp, population, ethnic fractionalization, and oil on democracy (ordinary least squares)
m2 <- lm(polity2l ~ lgdpenl1 + lpopl1 + ethfrac + Oil, data=fldat, na.action=na.omit)
summary(m2)


###############################################################################################################################
#### Substantive Effects
############
#EXERCISE 3#
############
## create a model matrix for Model 2 that models the effect of GDP on Polity - plot as many points of GDP as you want
  # hint: check out the sequence command that creates an evenly-spaced series of values between two end points (e.g., min and max fo GDP variable)
  # hint 2: think how many predicted Polity values yuo need given the number of different GDP values and the interaction with oil

gdpvals <-seq(min(m2$model$lgdpenl1), max(m2$model$lgdpenl1), by=.1) # create a sequence of gdp values
n_gdp <- length(gdpvals) # note number of values to be predicted
pmat2_gdp <- matrix(c(rep(1,n_gdp), # intercept
                      gdpvals, # GDP per capita
                      rep(mean(m2$model$lpopl1), n_gdp),  # population
                      rep(mean(m2$model$ethfrac), n_gdp), # ethnic fractionalization
                      rep(0, n_gdp)), # non-oil exporting as it is the mode
                    nrow=n_gdp) # prediction matrix for model 2  (pmat2) 
pmat2_gdp <- as.data.frame(pmat2_gdp) # change data type to data.frame
names(pmat2_gdp) <- c("Intercept", names(m2$model)[2:5]) # label variables

pp2_gdp <- predict(m2, pmat2_gdp, se.fit=TRUE, interval="confidence") # predict
head(pp2_gdp$fit) # check predictions

###############################################################################################################################
#### Plots

############
#EXERCISE 4#
############

## compute the predicted Polity score along the range of GDP scores for an otherwise average country
  # plot a line of different values of GDP on the x-axis and different Polity scores on the y-axis
  # Hint: this time we do not need special labels on the x-axis; just enable axis in the main plot window
  # add confidence intervals as a polygon behind the average predicted polity score line - see ?polygon
  # Hint: google "r plot polygon transparency" to make the polygon see-through

# Prepare plot data by adding x-axis value and labels
pp2plot_gdp <- data.frame(gdpvals, # these are the values for which we predicted polity scores 
                          polpredict=pp2_gdp$fit[,1], 
                          lci=pp2_gdp$fit[,2], 
                          uci=pp2_gdp$fit[,3])

# plot
#pdf("figures/oil_effect-160320.pdf", width=6, height=6)
plot(x=pp2plot_gdp$gdpvals, y=pp2plot_gdp$polpredict, 
     type="l",# line
     xlab="GDP per capita", # x-label
     ylab="Predicted Polity Score", # y-label
     axes=T # this time, we want axes to be automatically drawn
)

polygon(x=c(gdpvals, gdpvals),  # we need one set of x-values (here GDP) for the upper, and one for the lower boundary
        y=c(pp2plot_gdp$lci, pp2plot_gdp$uci), 
        col=rgb(1, 0, 0,0.5)) # add confidence intervals
#dev.off()

## Plot gdp effect with ggplot2
ggplot(data=pp2plot_gdp) + 
  theme_bw() + # black-white theme
  xlab("") + ylab("Predicted Polity Score") + # axis labels
  geom_line(aes(x=gdpvals, y=polpredict), size=1) + # average effect of oil (points) + confidence intervals (range)
  geom_ribbon(aes(x=gdpvals, ymin=lci, ymax=uci), alpha=0.3, size=1) # in ggplot, the alpha parameter controls transparency

ggsave("figures/gdp_effect-ggplot-160321.pdf", width=6, height=6) # ggplot export (always saves last plot)



