###############################################################################################################################
#### Project: Exeter Q-Step Workshop: Presenting regression results
#### Author: Nils-Christian Bormann
#### Task: New set of analyses
#### Version:
#1# 20 Mar 2016: Export regression tables (Stargazer) and plot predicted probabilities (Base-R)
#2# 21 Mar 2016: Add ggplot code and random effects model + ülots


###############################################################################################################################
#### Header
rm(list=ls()) # remove objects from R's memory
setwd("")

library(stargazer)

###############################################################################################################################
#### Data
fldat <- read.dta13("data/FL03.dta")

###############################################################################################################################
#### Analysis
## Regress population, ethnic fractionalization, and oil on democracy (ordinary least squares)
m1 <- lm(polity2l ~ lpopl1 + ethfrac + Oil, data=fldat, na.action=na.omit)
summary(m1)

## Regress gdp, population, ethnic fractionalization, and oil on democracy (ordinary least squares)
m2 <- lm(polity2l ~ lgdpenl1 + lpopl1 + ethfrac + Oil, data=fldat, na.action=na.omit)
summary(m2)

## Regress gdp, population, ethnic fractionalization, and oil on democracy + country and year fixed effects (ordinary least squares)
m3 <- lm(polity2l ~ factor(ccode) + factor(year) + lgdpenl1 + lpopl1 + Oil, data=fldat, na.action=na.omit)
summary(m3)

## Regress gdp, population, ethnic fractionalization, and oil on democracy (ordinary least squares)
m4 <- lm(polity2l ~ lgdpenl1*Oil + lpopl1 + ethfrac, data=fldat, na.action=na.omit)
summary(m4)

###############################################################################################################################
#### Tables
## Explore what some of the options do
  # either change them, for example, from TRUE to FALSE or vice versa
  # or read up on them in the help file ?stargazer
## Remove Residual Standard Error from table
## Add name of Dependent variable to table
## Add Model 4 to the table
  # reorder variables so that the table indicates, GDP first, oil*gdp second, and oil third with population and ethnic fractionalizaton afterwards
  # hint: pay attention to the variable labels

stargazer(m1, m2, m3, m4, 
          style="default",
          type="text", 
          #out="tables/regtab2_160320", # output directory
          order=c("lgdpenl1", "lgdpenl1*Oil", "Oil", "lpopl1", "ethfrac"), # reorder
          covariate.labels=c("GDP (log)", "Oil*GDP", "Oil", "Population (log)", "Ethnic Fractionalization"), # reorder labels
          dep.var.labels.include=T, # DO show dependent variable name
          font.size="normalsize",
          column.sep.width="1pt", # width between fonts
          initial.zero=T,
          intercept.top=F,
          model.numbers=T,
          no.space=T,
          notes="Standard errors in parentheses.",
          notes.align="l",
          notes.append=T,
          omit="factor",
          omit.labels="Country/Year-Fixed Effects",
          omit.stat=c("rsq","max.rsq","lr", "logrank", "ser"), # add 'ser' for residual standard error as omit
          star.cutoffs=c(0.05, 0.01, 0.001),
          title="Explaining Levels of Democracy (OLS), 1945-1999."
)

