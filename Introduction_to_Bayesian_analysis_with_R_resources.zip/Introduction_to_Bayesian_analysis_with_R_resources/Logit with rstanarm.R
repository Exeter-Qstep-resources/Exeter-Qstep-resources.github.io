library(rstanarm)
library(ggplot2)
library(bayesplot) 

theme_set(theme_bw())

setwd("C:/Users/az310/Dropbox/Teach Bayesian/prepped")
#setwd("C:/Users/andre/Dropbox/Teach Bayesian/prepped")

rm(list=ls())
load("Canada 2008 election.RData")

# logit model of turnout
# interest = interest in general election
# knowledge = correct answers to the factual questions about politics
# highschool = high school education
# badegree = Bachelor's degree or higher
# demsati = satisfaction with democracy
# contacted = contacted by a party during the campaign period
fit <- stan_glm(voted ~ interest + knowledge + highschool + badegree + demsati + contacted,
                 data=survey,
                 family = "binomial",
                 seed=1234)
prior_summary(fit)
draws <- as.data.frame(fit)
summary(fit)
#launch_shinystan(fit)

# point estimates
post.means <- lapply(draws, mean)
post.medians <- lapply(draws, median)

# intervals
posterior_interval(fit,prob = 0.90, type="central") # central interval
require(coda)
HPDinterval(as.mcmc(draws), prob=0.90) # highest posterior density interval

plot(fit, plotfun="areas", pars="interest", prob=0.5)
plot(fit, plotfun="areas", pars="demsati", prob=0.5)

# model fit comparisons: compare models estimated using the same dataset
mysample <- fit[["data"]][-fit[["na.action"]],]
fit2 <- stan_glm(voted ~ interest +  contacted,
                 data=mysample,
                 family = "binomial",
                 seed=1234)
# "wildly-applicable information criterion"/"Watanabe-Akaike Information Criterion"
(waic.fit <- waic(fit))
(waic.fit2 <- waic(fit2))
loo_compare(waic.fit,waic.fit2)

## predicted probabilities against "interest" variable
mysample <- fit[["data"]][-fit[["na.action"]],]
varnames <- all.vars(formula(fit))
xvar <- "interest"
newsample <- lapply(mysample[varnames], mean)
newsample[[xvar]] <- seq(from=min(mysample[[xvar]]), to=max(mysample[[xvar]]), length.out=20)
newsample <- as.data.frame(newsample)
pred.prob <- posterior_linpred(object = fit, newdata = newsample, transform=TRUE)
newsample[c("lb","ub")] <- posterior_interval(pred.prob, prob=.9)
newsample[["prprob"]] <- colMeans(pred.prob) 
ggplot(data=newsample, mapping=aes_string(x=xvar)) + 
  geom_line(aes(y=prprob), linetype="solid", size=1) +
  geom_line(aes(y=lb), linetype="dashed") +
  geom_line(aes(y=ub), linetype="dashed")