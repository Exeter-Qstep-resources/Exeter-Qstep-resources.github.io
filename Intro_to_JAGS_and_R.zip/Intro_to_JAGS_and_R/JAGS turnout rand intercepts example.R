library(foreign)
library(rjags)
library(mcmcplots)

setwd("C:/Users/az310/Dropbox/Teach Bayesian/prepped") 

rm(list=ls())

## define the model
model <- "
data {
  J <- dim(x.dist)
  G <- dim(x.ind)
}
model{
  for (i in 1:G[1]) {
  	y[i] ~ dbern(theta[i])
	  logit(theta[i]) <- mu[dcode[i]] + inprod(x.ind[i,],b.ind)
    }
  for (j in 1:J[1]){
    mu[j] <- alpha + inprod(x.dist[j,],b.dist) + u[j]
	  u[j] ~ dnorm(aveu,tau)
    }
  for (g in 1:G[2]) {
    b.ind[g] ~ dnorm(0,0.1)
    }
  for (f in 1:J[2]) {
    b.dist[f] ~ dnorm(0,0.1)
   }
  alpha ~ dnorm(0,0.1)
  aveu ~ dnorm(0,0.1)
  tau ~ dgamma(0.001, 0.001)
}"

load("Canada 2008 election.RData")

# delete observations with missing values
dist <- na.omit(districts[c("district","lnspending","ncand","vmargin")])
ind <- na.omit(survey[c("district","voted","interest","knowledge","highschool","badegree","demsati","contacted")])

# keep only the observations with district- and
# respondent-level information 
dist <- subset(dist, district %in% unique(ind[["district"]]))
dist <- dist[!duplicated(dist$district),]
dist <- dist[order(dist$district),]
dist.codes <- data.frame(district=dist$district, dcode=1:nrow(dist))
ind <- merge(ind, dist.codes, by="district") 

# extract pieces
y <- ind[["voted"]] 
x.ind.vars <- c("interest","knowledge","highschool", "badegree","demsati","contacted")
x.ind.list <- lapply(ind[x.ind.vars], FUN=scale)
x.ind.centers <- sapply(x.ind.list, FUN=attr, which="scaled:center")
x.ind.iscales <- sapply(x.ind.list, function(x) 1/attr(x,"scaled:scale"))
x.ind <- as.matrix(do.call("cbind",x.ind.list))
x.dist.vars <-c("lnspending","ncand","vmargin")
x.dist.list <- lapply(dist[x.dist.vars], FUN=scale)
x.dist.centers <- sapply(x.dist.list, FUN=attr, which="scaled:center")
x.dist.iscales <- sapply(x.dist.list, function(x) 1/attr(x,"scaled:scale"))
x.dist <- as.matrix(do.call("cbind",x.dist.list))
dcode <- ind[["dcode"]]

## define the list of data
mydata <- list(y=y,x.ind=x.ind,x.dist=x.dist,dcode=dcode) 

## list parameters
bayes.mod.params <- c("b.ind","b.dist","alpha","u")

# ### initialize and compile
# mod.fit <- jags.model(textConnection(model), data=mydata, n.chains = 3, n.adapt=500)
# ### burn-in samples
# update(mod.fit,7000)
# ### monitored samples
# mcmc_samples <- coda.samples(mod.fit, variable.names=bayes.mod.params, thin=7, n.iter=7000)
# #dic_samples <- dic.samples(mod.fit, n.iter=2000)

#save(list=c("mcmc_samples","dic_samples"),file="Samples Rand Intercepts.RData")

load("Samples Rand Intercepts.RData")
## check the estimates
mcmcplot(mcmc_samples)
(rhos <- gelman.diag(mcmc_samples))

# find the global intercept
mu.cols <- paste0("u[",1:nrow(x.dist),"]")
mcmc_samples.red <- lapply(mcmc_samples, function(x) {
    y <- x[,setdiff(colnames(x),c(mu.cols,"alpha"))]
    alpha <- as.matrix(x)[,"alpha"] + rowMeans(as.matrix(x)[,mu.cols])
    as.mcmc(cbind(y,alpha))
    })
mcmcplot(mcmc_samples.red)
(rhos <- gelman.diag(mcmc_samples.red))
(n_eff <- effectiveSize(mcmc_samples.red)) 

## combined chains
mcmc.all <- mcmc(do.call(rbind,mcmc_samples.red))
map <- data.frame(
  oldname = c(paste0("b.dist[",1:length(x.dist.vars),"]"),
        paste0("b.ind[",1:length(x.ind.vars),"]"), "alpha"),
  newname = c(paste0("district:",x.dist.vars),paste0("respondent:",x.ind.vars), "alpha"))
colnames(mcmc.all) <- map[match(colnames(mcmc.all), map$oldname), "newname"]

## summarise
sums.all <- summary(mcmc.all)
sums.all[["statistics"]]

# credible intervals
ci.central <- data.frame(
  lower=apply(mcmc.all, 2, quantile,probs=0.05),
  upper=apply(mcmc.all, 2, quantile,probs=0.95))
ci.hpd  <- HPDinterval(mcmc.all)

forplot <- data.frame(var=rownames(sums.all[["statistics"]]),sums.all[["statistics"]], ci.central)
require(ggplot2)
ggplot(subset(forplot, var!="alpha"), aes(x=var, y=Mean)) + 
  geom_point() +
  geom_errorbar(aes(ymin=lower, ymax=upper)) +
  theme_bw() + coord_flip()

above.zero <- mcmc.all
above.zero[,] <- as.numeric(mcmc.all[,]>0)
pct.above.zero <- 100*colMeans(above.zero)
