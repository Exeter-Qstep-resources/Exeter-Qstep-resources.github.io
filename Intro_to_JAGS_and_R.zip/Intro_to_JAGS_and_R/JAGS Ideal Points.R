library(foreign)
library(rjags)
library(mcmcplots)

setwd("C:/Users/az310/Dropbox/Teach Bayesian/prepped")

rm(list=ls())

## define the model
model <- "
data{
  N <- length(y)
  }
model{
  for (i in 1:N){
	  y[i] ~ dbern(y.hat[i])
	  logit(y.hat[i]) <- 2*diff[cid[i]]*theta[rid[i]] - diffsq[cid[i]]
  } 
  for (k in 1:K){
    diffsq[k] <- sum[k]*diff[k]
    sum[k] ~ dnorm(0,0.5)
    diff[k] ~ dnorm(0,0.5)
  }
  for (j in 1:J){ 
    theta[j] ~ dnorm(ideol[j],1)
  }
}"

load("113th Senate Roll Calls.RData")

rc <- subset(rollcalls, vote %in% c(1,6))
# remove the bills without variation
tab <- table(rc$call, rc$vote)
rsums <- rowSums(table(rc$call, rc$vote))
tab <- tab[,1]/rsums
bills <- setdiff(unique(rc[["call"]]), names(tab[tab>0.95]))
# randomly pick 200 bills -- the estimation will be more accurate if one uses all the votes
bills <- sample(bills,200)
bill.codes <- data.frame(call=bills,cid=1:length(bills))
# extract senators
senators <- reps[!duplicated(reps[["id"]]),c("id","party")]
rep.codes <- subset(senators, id %in% rc[["rep.id"]])
rep.codes[["rid"]] <- 1:nrow(rep.codes)
ideol <- data.frame(party=c(100,200,328), ideol = c(-1,1,0))
rep.codes <- merge(rep.codes,ideol,by="party")  
rc <- merge(rc,bill.codes,by="call")
rc <- merge(rc,rep.codes,by.x="rep.id",by.y="id")

## define the list of data
mydata <- list(y=as.numeric(rc[["vote"]]==1),
               rid=rc[["rid"]], 
               cid=rc[["cid"]],
               ideol=rep.codes[order(rep.codes[["rid"]]),"ideol"],
               J=nrow(rep.codes),
               K=nrow(bill.codes))

rm(list=c("rc","rollcalls","reps"))

## list parameters
bayes.mod.params <- c("theta","diff","sum")

### run mcmc
# mod.fit <- jags.model(textConnection(model), data=mydata, n.chains = 3, n.adapt=200)
# update(mod.fit,7000)
# mcmc_samples <- coda.samples(mod.fit, variable.names=bayes.mod.params, thin=7, n.iter=7000)
# save(mcmc_samples, file="Samples Ideal Points.RData")

load("Samples Ideal Points.RData")
## check the estimates
mcmcplot(mcmc_samples)
gelman.diag(mcmc_samples)

mcmc.all <- mcmc(do.call(rbind,mcmc_samples))
theta.est <- data.frame(
  param = colnames(mcmc.all),
  estimate = colMeans(mcmc.all))
theta.est <- subset(theta.est, grepl("theta",param))
theta.est <- within(theta.est,
    rid <- as.numeric(gsub("[^0-9]+", "\\1", param))
      ) 
theta.est <- merge(theta.est, rep.codes, by="rid") 
theta.est <- within(theta.est,
     party <- factor(party, levels=c(100,200,328),
                  labels=c("Dem","Rep","Ind")))


require(ggplot2)
ggplot(theta.est, aes(x=estimate,
                      colour=party, fill=party)) + 
  geom_histogram(alpha=0.5) +
  theme_bw()


