library(foreign)
library(rjags)
library(mcmcplots)

setwd("C:/Users/az310/Dropbox/Teach Bayesian/prepped")

rm(list=ls())

## define the model
model <- "
data {
  N <- length(y)
  G <- dim(x)
  }
model{
  for (i in 1:N) { 
    y[i] ~ dbern(theta[i])
    logit(theta[i]) <- alpha + inprod(x[i,],beta)
  }
  alpha ~ dnorm(0,1)
  for (g in 1:G[2]) {
    beta[g] ~ dnorm(0,1)
  }
}"

load("Canada 2008 election.RData")

# delete observations with missing values
ind <- na.omit(survey[c("district","voted","interest","knowledge","highschool","badegree","demsati","contacted")])

# extract pieces
y <- ind[["voted"]]
x.ind.vars <- c("interest","knowledge","highschool", "badegree","demsati","contacted")
x.ind.list <- lapply(ind[x.ind.vars], FUN=scale)
x.ind.centers <- sapply(x.ind.list, FUN=attr, which="scaled:center")
x.ind.iscales <- sapply(x.ind.list, function(x) 1/attr(x,"scaled:scale"))
x.ind <- as.matrix(do.call("cbind",x.ind.list))
 
## define the list of data
mydata <- list(y=y,x=x.ind)

## list parameters to monitor
bayes.mod.params <- c("beta","alpha")

# ## initialize and compile the model
# mod.fit <- jags.model(textConnection(model), data=mydata, n.chains = 3, n.adapt=200)
# # run MCMC without recording the path (burn-in samples)
# update(mod.fit,3000)
# ## run MCMC and monitor parameter values
# mcmc_samples <- coda.samples(mod.fit, variable.names=bayes.mod.params, thin=3, n.iter=3000)
# ##deviance information criterion
# dic_samples <- dic.samples(mod.fit, n.iter=2000)

#save(list=c("mcmc_samples","dic_samples"),file="Samples Ind Logit.RData")

## check the estimates
load("Samples Ind Logit.RData")

mcmcplot(mcmc_samples)
(rhos <- gelman.diag(mcmc_samples))
(n_eff <- effectiveSize(mcmc_samples)) 

## combined chains
mcmc.all <- mcmc(do.call(rbind,mcmc_samples)) 
## use variable names to rename the columns
map <- data.frame(
  oldname = c(paste0("beta[",1:length(x.ind.vars),"]"), "alpha"),
  newname = c(x.ind.vars, "alpha"))
colnames(mcmc.all) <- map[match(colnames(mcmc.all), map$oldname), "newname"]

# summarise
sums.all <- summary(mcmc.all)
sums.all[["statistics"]]

# credible intervals
ci.central <- data.frame(
             lower=apply(mcmc.all, 2, quantile,probs=0.05),
             upper=apply(mcmc.all, 2, quantile,probs=0.95))
ci.hpd  <- HPDinterval(mcmc.all)

above.zero <- mcmc.all
above.zero[,] <- as.numeric(mcmc.all[,]>0)
pct.above.zero <- 100*colMeans(above.zero)

## rescale the parameters if they are to be used with unscaled data
alpha <- mcmc.all[,"alpha"]
beta <- mcmc.all[,x.ind.vars]
beta.rescaled <- sweep(beta, 2, STATS=x.ind.iscales, FUN="*")
alpha.rescaled <- alpha - beta.rescaled %*% x.ind.centers
 
xvar <- "interest"
newsample <- lapply(ind[x.ind.vars], mean)
newsample[[xvar]] <- seq(from=min(ind[[xvar]]), to=max(ind[[xvar]]), length.out=20)
newsample <- as.matrix(do.call("cbind",newsample))
predprob <- apply(newsample, 1, function(x) 1/(1+exp(-alpha.rescaled - beta.rescaled %*% x)))
sums <- data.frame(
  interest = newsample[,"interest"],
  prprob=colMeans(predprob),
  lb=apply(predprob, 2, quantile,probs=0.05),
  ub=apply(predprob, 2, quantile,probs=0.95))

require(ggplot2)
theme_set(theme_bw())
ggplot(data=sums, mapping=aes(x=interest)) + 
  geom_line(aes(y=prprob), linetype="solid", size=1) +
  geom_line(aes(y=lb), linetype="dashed") +
  geom_line(aes(y=ub), linetype="dashed")
