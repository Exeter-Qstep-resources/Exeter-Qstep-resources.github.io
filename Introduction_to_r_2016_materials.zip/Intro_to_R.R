# Intro to Programming in R
# Exeter Q-Step Workshops
# Iulia Cioroianu
# January 2016


#######################################################################
## PART 1: Introduction, installing and setting up R and RStudio
#######################################################################

# Downloading and installing R: https://cran.r-project.org/
# Downloading and installing RStudio: https://www.rstudio.com/products/rstudio/download/

# Starting an R session
# Windows: Rgui.exe. 
# MAC: R.app. 
# UNIX: you enter the command R (the path must include the R binaries).

# Writing scripts
# You can write anything in the console, but it is much more convenient to write a script that you can then run (in chunks or in full).
# Script/program - collection of expressions to be evaluated sequentially.
# You can write scripts in the R GUI, but it is much more convenient to use a text editor such as Emacs, VIM, Eclipse, 

# OR

# The amazing IDE (integrated development environment) for R: RStudio. 

# Quick guide through what you see in RStudio.  

#####################################
# Working directory
#####################################

# What is he current wd? 
getwd()
# Change the working directory to the folder we created at the beginning: 
setwd("U:/Rintro")
# What it in the working directory? 
list.files()
# List the folders and sub-folders: 
list.dirs()


#####################################
# Getting help
#####################################

# In RStudio: the Help panel in the lower-right window. Try it out! 
# In general, in R, find out more about an R command or function x, help(x) or ?x. 
help(median)
?lm
# Search the titles, names, aliases, and keyword entries of the available help files for the phrase x:
help.search("regular expression")
help.start() #HTML help interface


#######################################################################
## PART 2: Basic computing in R
#######################################################################


#####################################
# Arithmetic operations
#####################################

((1 + 2/3)*3)^2 
sqrt(25) # square root
exp(1) # exponential
options(digits = 20) # set number of digits to display
exp(1) 
options(digits = 6)
log(2.7183) # logarithm 


#####################################
# Functions
#####################################

# Multiple built-in functions were used above. 
# A function takes one or more arguments (or inputs) and produces one or more outputs (or return values).
# You write the name of the function followed by the argument in round brackets. 
pi 
sin(pi/6) # sine function
round(pi) # round to nearest integer
seq(from = 1, to = 7, by = 2) # produces sequences of numbers from 1 to 9, every 2
seq(from = 1, to = 7) # the default value fot the third argument is 1
seq(1, 9, 3) # if you do not specify the names of the arguments (from, to, by) then the order you list them in in the function is assumed to be the default one 


#####################################
# Variables
#####################################

# "Expression" - a phrase of code that can be executed.
# "Assignment" - saving the evaluation of an expression, assigning it to a variable. 

a=1 # variables are created the first time you assign a value to them. 
a # display the value of variable a
A <- 2 # names are case sensitive.
print(A) # display the value of variable A
a+A/10 # evaluate value of this expression
a <- a+1 # you can have a variable both on the left and the right
a
seq(a-1, 7, a) # you can place variables inside functions


#####################################
# Use <- or = ?
#####################################

# Can use either = or <- for assignment. They do the same thing. Some prefer one, some prefer the other. 
# In this tutorial I will use <- because it is more widely used. 
# I prefer = because it is easier to use and similar to other programming languages that I use. 
# To get <-  in RStudio, use Alt- as a shortcut. Note that it includes spaces around it. 
# It is good practice to have these spaces, although they are not (always) necessary.  
# It is also good practice to give informative names to your variables. 


#####################################
# Vectors
#####################################

# A vector is an indexed list of variables. Created the first time a value is assigned to them, just like variables. 
# A variable is a vector with length 1. 
# Vectors are created by using functions such as c()-combine, seq(from, to, by)-sequence, rep(x, times)-repetition. 
v1 <- c(1, 2, 3, 4)
v2 <- seq(1,7,2)
v3 <- rep(2,3)
v4 <- c(v2,v3) # we can combine vectors as well
#To refer to element i of vector x, we use x[i].
v1[1]
v2[2:3] # Get elementf "from:to"
length(v3) # the number of elements of vector v3

# Algebraic operations on each element separately (elementwise):
v1+v2
v1*v2
v1*v3 # Note the warning message. The two vectors need to wither be the same length or one be a multiple of the other. 
      # If not, R duplicates the shorter one, but produces the warning. 
2+v3 # Therefore if one of them is of length 1, this works. 

# Applying functions to vectors
# Note that some functions applied to vectors act on the whole vector:
sum(v1)
mean(v1)
var(v1)
prod(v1)
min(v1)
max(v1)
# while others act elementwise:
sqrt(v1)
sort(v1, decreasing=TRUE)


#####################################
# Logical expressions: True or False
#####################################

# Comparison operators <, >, <=, >=, == (equal to), and != (not equal to). 
# Logical operators & (and), | (or), and ! (not). 
v1==v2
# 0 and 1 cna be used to mean true or false
c(0,1,1) | c(1,1,0) # True if either one of them true
xor(c(0,1,1), c(1,1,0)) # exclusive disjunction - either one or the other but not both

# Selecting a subset of a vector for which a certain condition is true: 
v1 > 2
v1[v1 > 2]

# Finding the position of elements which meet a certain condition: 
which(v4>=5)

# Missing data
m <- NA # assign NA to variable a
is.na(m) # is it missing?
m <- c(1,NA,3) # NA in a vector
is.na(m) # is it missing?
mean(m) # NAs can propagate
mean(m, na.rm = TRUE) # NAs can be removed


#####################################
# Matrices
#####################################

# Created from a vector using the function matrix(data, nrow = 1, ncol = 1, byrow = FALSE).
# If length(data)<nrow*ncol, then data is reused as many times as is needed. 
matrix(0, 2, 2)
matrix(c(1,2), 2, 2)
matrix(c(1:6), 2, 3)
matrix(1:6, 2, 3, TRUE)
# To create a diagonal matrix:
diag(1:3)

# We refer to the elements of a matrix using two indices: the first one for row, the second for column
A <- matrix(1:6, 2, 3)
A[1, 3] <- 0
A[, 2:3]

# Get the number of rows and columns of the matrix:
nrow(A)
ncol(A)

# To join matrices with rows of the same length (stacking vertically):
rbind(A, c(1:3))
# To join matrices with columns of the same length (stacking horizontally) use cbind(...).
cbind(A, c(1:2))

# Algebraic operations act elementwise on matrices:
A+A  
A*A

# For matrix multiplication, use %*%:
A%*%t(A) # multiply A by its transpose
solve(A%*%t(A)) # get the inverse of the above square matrix

# From vector to matrix and the other way around
is.vector(A) # test if A is a vector
is.matrix(A) # test if A is a matrix
B <- as.matrix(v1) # create a matrix of 1 column out of a vector
x <- as.vector(A) #create a vector from the columns of a matrix (stored columnwise)


#######################################################################
## PART 3: Basic Programming
#######################################################################

#####################################
# Control structures
#####################################

#if
if (A[1,1]==1) {
  print("First element of first column is 1")
}

# if, else
if (A[1,1]==2) {
  print("First element of first column is 2")
} else {
  print("First element of first column is not 2")
}

# ifelse
v <- c(1,2,3,4,5,6)
ifelse(v %% 2 == 0,"even","odd")

# for
for(i in v2) {
  print(i)
}

# while
j <- 1
while (j < 5) {
  print(j)
  j = j+1
}

#####################################
# Writing your own functions
#####################################
myfunction <- function(x, y) {
  # function that raise c to the power y
  result <- x^y
  print(paste(x,"raised to the power",y,"is",result))
}
# Calling the function
myfunction(2,5)
myfunction(3,7)

#######################################################################
## PART 4: Working with dataframes
#######################################################################

# We have the following vectors: 
a <- c(78, 89.5, 82, 36.5, 74, 39) # numeric vector
b <- c("one","two","three","six","five","four") # character vector
c <- c(TRUE,TRUE,TRUE,FALSE,TRUE,FALSE) #logical vector
d <- c("red","blue","yellow", NA, NA, NA) # character vector


# Create a dataset out of the vectors above
mydata <- data.frame(a,b,c,d)
# Give names to the variables (the vectors)
names(mydata) <- c("score","exam_seat", "passed","color") # variable names

#Identify and inspect the elements of a data frame:
mydata # prints the data
View(mydata) # opens the dataframe in a new tab 
names(mydata) # print the names of the variables
nrow(mydata) # the number of observations in the dataset (number of rows)
ncol(mydata) # the number of variables in the dataset (number of columns)
mydata[2:4] # prints columns 2,3,4 of data frame
mydata[c("score","color")] # prints columns id and color from data frame
mydata$passed # prints variable 'passed' from the data frame 

# Subsetting - selecting only certain observations and/or certain variables. 
newdata1 <- subset(mydata, score<=80) # Select only observations with id greater or equal than 3, put them in a new object called 'newdata'
newdata1
newdata2 <- subset(mydata, score<80 & passed==TRUE) # Select only observations with id greater than 3 and which didn't pass (so passed==FALSE)
newdata2
newdata3 <- subset(mydata, passed==TRUE, select=c(score,passed)) # Select only observations which passed AND keep only the variables 'id' and 'passed' in the new dataset. 
newdata3

# Aggregate/collapse data
# aggregate(cbind(var1, var2, var3)~cat_var1+cat_var2, data=mydata, mean) # get the means of var1, var2 and var3 BY the categories of categorical variables cat_var1 and cat_var2 (instead of mean you can also get sum, median, min, max) 
aggregate(cbind(score)~passed, data=mydata, mean) # Get the mean score for the group that failed and that that passed
# You can assign the result of the aggregation to a new dataframe
collapsed_data <- aggregate(cbind(score)~passed, data=mydata, mean) 

#############################################
#Generate and modify variables
#############################################

# To create a new variable in a dataset you just have to declare it. 
mydata$newvar <- NA # generate a new empty variable (full of NAs). 
ncol(mydata)
# If you declare any variable in the dataset again, it gets overwritten without any warning. So be careful with this!  
mydata$newvar <- 0 # the already existing variable 'newvar' is changed to all 0s. 
# It's always good practice to copy a variable that you want to make changes into a new variable, and modify the new one/ 
mydata$newvar <- mydata$score # replace the values of 'newvar' with the values of 'score'

# Assign values to a variable, conditional on something:
mydata$newvar[mydata$score!=78] <- 0 # if score different from 78, newvar is 0. 
mydata$newvar[mydata$score==78] <- 1 # if score is equal to 78, newvar is 1. (You can also use <, <=, >, >=)
mydata
mydata$newvar[mydata$score<=80 & mydata$passed==TRUE] <- 1 # if score<=80 AND passed is true then newvar becomes 1
mydata$newvar[is.na(mydata$color)==TRUE | mydata$score==TRUE | mydata$exam_seat=="three"] <- 2
# above says: if color is missing OR score is 1 OR exam_seat is 'three' then replace the value of newvar with 2
mydata

# NOTE: You only need qutation marks in the condition for string variables (variables whose values are words), 
# do NOT use quotation marks for number variables (whose values are either only numbers or a combination of numbers and missing data(NA)) 
# and do NOT use quotation marks for TRUE/FALSE variables. 

# Create a dummy variable (a variable with only two categories)
mydata$newvar2 <- ifelse(is.na(mydata$color)==TRUE, 1, 0) # Create a variable newvar2 which takes the value 1 if color is not missing, and 0 if color is missing. 
mydata

################################################                    
# A. Importing and saving your own data
################################################

#"Import data" in the Environment window
# Make sure you give the imported data frame a short name. 
# Check 'Yes' for heading if the variable names are on the first row.

# OR:
data <- read.csv(file.choose(''), header=TRUE)
# Now choose the file to open. 

# OR
# Use file location (make sure you change this to match the location where you saved the file):
data <- read.csv("U:/Rintro/mydataset.csv")

# OR:
# Set the working directory to be the folder where you have the data:
setwd("U:/Rintro/")
# now you can read the data directly from the folder. Everything that you save will also go to that folder. 
read.csv("mydataset.csv")

# Saving data
# Let's say you have a data frame object called 'mydata' that you want to save as a .csv file: 
write.csv(data, file="U:/Rintro/saved_data.csv")
# Or, if you've already set the working directory just give it a name and it will automatically be saved in the working directory location. 
write.csv(data, file="saved_data.csv")


#######################################################
# Descriptive statistics
#######################################################

# Mean, median, 25th and 75th quartiles, min, max, number of NA (if no NA given then no NAs exist for that variable)
summary(data) # for ALL the variables in the dataset:
summary(data$spent) # for a single variable 

# One measure at a time
length(na.omit(data$reelected)) # The number of non-missing observations
mean(data$reelected, na.rm=T)            # The mean
sd(data$reelected, na.rm=T)              # The standard deviation
min(data$reelected, na.rm=T)             # The minimum value
max(data$reelected, na.rm=T)             # The maximum value

# Using the "psych" package:
install.packages('psych') # install psych if it is not already installed. You only do this once.
library(psych)            # load the package into your R session
describe(data)            # Get descriptive statistics

#######################################################
# Frequency and proportions tables: 
#######################################################

# Frequency table:
mytable <- table(data$party,data$reelected) # var1 will be on the rows, var2 will be on the columns
mytable # print table
# Relative frequency (or proportions) table. Note that this is a table of the frequency table defined above. 
prop.table(mytable) # cell percentages
prop.table(mytable, 1) # row percentages
prop.table(mytable, 2) # column percentages 

##############################################
# Correlations
##############################################

cor(data$spent, data$raised) # correlation between var1 and var2. var1 and var2 need to be numeric. 
cor(data$spent, data$raised, use="complete.obs") # only use complete cases if there is any missing data in var1 and var2. 
cor.test(data$spent, data$raised, use="complete.obs") # test significance

#######################################################
# Simple plots
#######################################################

# General syntax:
# PlotType(data_to_plot, option1, option2, option3, etc)
# where:
# PlotType can be: plot(does a scatterplot), barplot, pie (for piechart), hist(for histogram), boxplot, etc. 
# data_to_plot can be a variable, a table, data coming from some model, etc. 
# options can be: 'main' and 'sub' for main title and sub-title; 'col' for changing colors; 'ylab' and 'xlab' for labeling the axes; legend; names.arg for labeling plot elements etc. 

#Let's first attach the dataset so we can refer to variable names directly
attach(data)

# Examples:
# Histogram: 
hist(spent) # simple histogram
hist(spent, breaks=12, col="red") # red histogram with different number of bins  

# Barplots:
barplot(table(reelected)) # Simple bar plot of a a frequency table for a variable (an ordinal or binary variable)
barplot(table(reelected), main="Number of observation per category of var2", xlab="Category of var2") # Same plot with title and labeled x axis
barplot(table(reelected,party)) # stacked bar plot of the number of observations by group of var1 and var2
barplot(prop.table(table(reelected,party)), col=c("red", "blue", "green", "yellow", "black", "purple")) # stacked bar plot of the proportion of observations per group of var1 and var2, also with different colors for the categories of var1
barplot(prop.table(table(reelected,party)), col=rainbow(6), beside=TRUE) # same as above, but grouped bar plot (not stacked but aside) and letting R choose the colors

# Scatterplots
plot(spent, raised) # Simple scatterplot of variables x and y. 
#This order puts x on the horizontal axis and y on the vertical one. 
#Note that the order is particularly important if you want to add a linear fit line:  
abline(lm(spent~raised), col="red") # add a regression line (y~x)
lines(lowess(spent, raised), col="blue")
# Matrices of scatterplots, for multiple variables (two by two)
pairs(~spent+raised+reelected, data=data, main="Simple Scatterplot Matrix")

# Piecharts
pie(table(party)) # Simple pie chart of var1

#Put two graphs in the same plot, one next to the other:
par(mfrow=c(1,2)) # This divides the plotting space into two vertical cells
pie(table(party))
pie(table(chamber))
par(mfrow=c(1,1)) # This turns it back to a single cell


# Saving the workspace
# What do we do with all these objects we created? 
ls() # list all currently defined objects
rm(a) # remove object a 
# rm(list = ls()) - remove all currently defined objects. Only do this if you're very sure!
save.image(file = "fname1") #save all of existing objects to a file called fname in the current working directory
save(x, y, file = "fname2") # save specific objects
load(file = "fname") # load a set of saved objects
savehistory(file = "history_file") # Save history of commands
#At the end, asked if you wish to save your workspace image - save your existing objects to the file .RData in the wd and history to .RHistory.


#######################################################################
## R resources
#######################################################################

# Today's lab relied heavily on "Introduction to Scientific Programming and Simmulation Using R"
# by Jones, Millardet and Robinson
# https://www.crcpress.com/Introduction-to-Scientific-Programming-and-Simulation-Using-R-Second-Edition/Jones-Maillardet-Robinson/9781466569997

# Large number of introductions to R on the web
# http://www.r-tutor.com/r-introduction
# http://tryr.codeschool.com/
# http://www.statmethods.net/

# Very good resource for more advanced programming:
# Hadley Wickham's Advanced R (which is not THAT advanced)
# http://adv-r.had.co.nz/




